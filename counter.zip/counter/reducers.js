import { combineReducers } from 'redux';

// const currentReducer = (currentCount = 0) => {
//     return {current: currentCount};
// };

const counterReducer = (currentCount = 0, action) => {
    if (action.type === 'INCREASE') {
        return currentCount + 1
    }
    if (action.type === 'DECREASE') {
        return currentCount - 1
    }
    if (action.type === 'INPUT') {
        return (action.payload)
    }
    return currentCount;
};

export default combineReducers({
    // random: currentReducer,
    counterValue: counterReducer
});