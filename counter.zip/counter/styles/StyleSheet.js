import index from './index.css';

export const StyleSheet = {index};