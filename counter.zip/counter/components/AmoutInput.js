import React, {Component} from 'react';
import { connect } from 'react-redux';
import { input } from '../actions/countActions';

class AmountInput extends Component {
    render() {
        return (
            <div className='ui input'>
                <input type='number' placeholder='amount' onChange=
                    {
                        (e) => { 
                            this.props.input(e.target.valueAsNumber);
                        }
                    }>
                </input>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {counterValue: state.counterValue}
}

export default connect(mapStateToProps,{ input })(AmountInput);