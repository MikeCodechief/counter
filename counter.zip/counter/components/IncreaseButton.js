import React, {Component} from 'react';
import { connect } from 'react-redux';
import { increase } from '../actions/countActions';

class IncreaseButton extends Component {
    // constructor(props) {
    //     super(props);
    //     this.handleClick = this.handleClick.bind(this);
    // }
    // handleClick(){
    //     console.log("click!!");
    //     this.props.increase();
    // }

    render() {
        return(
            <div>
                {/* <button className='ui button' onClick = { this.handleClick() }> */}
                <button className='ui button' onClick = { ()=> this.props.increase()}>
                    +
                </button>
            </div>
        );
    }
}

const mapStateToProps = state => {
    // console.log(state.counterValue);
    return { value: state.counterValue };
}
export default connect(mapStateToProps,{increase})(IncreaseButton);