import React from 'react';
import { connect } from 'react-redux';

const CurrentCount = ({counterValue}) =>{
    // console.log(total);
    // if (!total) {
    //     return <div className='ui huge head'>0</div>;
    // }
    // console.log(counterValue);
    return <div className='ui huge head white-text'>{counterValue}</div>;
}

const mapStateToProps = state => {
    // console.log(state.counterValue);//counterValue is from reducers.js
    return {counterValue: state.counterValue};
}

export default connect(mapStateToProps)(CurrentCount);