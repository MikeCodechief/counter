import React, {Component} from 'react';
import { connect } from 'react-redux';
import { decrease } from '../actions/countActions';

class DecreaseButton extends Component {

    render() {
        return(
            <div>
                <button className='ui button' onClick = { () => {this.props.decrease()}}>
                    -
                </button>
            </div>
        );
    }
}

const mapStateToProps = state => {
    // console.log(state);
    // console.log(state.changedValue);
    // return { changedValue: state.changedValue };
    return {counterValue: state.counterValue};
}
export default connect(mapStateToProps,{decrease})(DecreaseButton);