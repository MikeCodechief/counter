import {INCREASE,DECREASE, INPUT, CREATE} from './types';

export const increase = () => {
    return{
        type: INCREASE
    };
};

export const decrease = () => {
    return{
        type: DECREASE
    };
};

export const input = value => {
    return {
        type: INPUT,
        payload: value
    };
};

export const create = () => {
    return {
        type: CREATE
    };
};