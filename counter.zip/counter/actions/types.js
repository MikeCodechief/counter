export const INCREASE = 'INCREASE';
export const DECREASE = 'DECREASE';
export const INPUT = 'INPUT';
export const CREATE = 'CREATE';