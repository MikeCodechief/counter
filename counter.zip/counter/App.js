import React from 'react';
import IncreaseButton from './components/IncreaseButton';
import DecreaseButton from './components/DecreaseButton';
import CurrentCount from './components/CurrentCount';
import AmountInput from './components/AmoutInput';
// import Login from './components/Login';
const App = () => {
    // return (<Login />);
    return(
        <div>
            <IncreaseButton />
            <DecreaseButton />
            <AmountInput />
            <CurrentCount />
        </div>
    );
}

export default App;
